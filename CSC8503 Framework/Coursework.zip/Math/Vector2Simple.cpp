#include "Vector2Simple.h"

const Vector2Simple Vector2Simple::ZEROS = Vector2Simple(0.0f, 0.0f);
const Vector2Simple Vector2Simple::ONES = Vector2Simple(1.0f, 1.0f);