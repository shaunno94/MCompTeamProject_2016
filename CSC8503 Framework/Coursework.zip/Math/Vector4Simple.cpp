#include "Vector4Simple.h"


const Vector4Simple Vector4Simple::ZEROS = Vector4Simple(0, 0, 0, 0);
const Vector4Simple Vector4Simple::ONES = Vector4Simple(1.0f, 1.0f, 1.0f, 1.0f);