/******************************************************************************
Author:Rich Davison
Description: Some random variables and functions, for lack of a better place 
to put them.

-_-_-_-_-_-_-_,------,   
_-_-_-_-_-_-_-|   /\_/\   NYANYANYAN
-_-_-_-_-_-_-~|__( ^ .^) /
_-_-_-_-_-_-_-""  ""   

*//////////////////////////////////////////////////////////////////////////////

#pragma once

#define WEEK_2_CODE
#define WEEK_3_CODE


#define SHADERDIR	"../../Shaders/"
#define MESHDIR		"../../Meshes/"
#define TEXTUREDIR  "../../Textures/"
#define SOUNDSDIR	"../../Sounds/"