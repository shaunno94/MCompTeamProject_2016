#include "DataSourceState.h"


DataSourceState::DataSourceState(GameObject& go) : State(go)
{
}

